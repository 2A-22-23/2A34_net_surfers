<?php
include "../connection.php";
class CrudBlocked
{
    public static function insert($Reclamation)
    {
        $sql = "INSERT INTO blocked (client) VALUES (:client)";
        $db = connection::getConnexion();

        try {
            $req = $db->prepare($sql);

            $req->bindValue(":client", $Reclamation->client);

            $x = $req->execute();
            return $x == true ? null : "error";
        } catch (Exception $e) {
            return 'Erreur: ' . $e->getMessage();
        }
    }

    public static function Delete($id)
    {
        $sql = "DELETE FROM blocked where id=:id";
        $db = connection::getConnexion();
        try {
            $req = $db->prepare($sql);
            $req->bindValue(':id', $id);
            $req->execute();
            return null;
        } catch (Exception $e) {
            return 'Erreur: ' . $e->getMessage();
        }
    }

    public static function FindAll()
    {
        $sql = "SELECT * FROM blocked";
        $db = connection::getConnexion();
        try {
            $result = $db->query($sql);
            return $result->fetchAll();
        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }
    }
}
?>