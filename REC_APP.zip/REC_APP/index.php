<?php
location("./view/index.php");
?>
