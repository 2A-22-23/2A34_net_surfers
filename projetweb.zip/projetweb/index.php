<!doctype html>
<html lang="en">
<head>
    <?php include 'include/head.php' ?>
    <title>Accueil</title>
</head>
<body>
<?php include 'include/nav.php' ?>
<div class="container py-2">
    <h4>Bienvenue</h4>
</div>

</body>
</html>